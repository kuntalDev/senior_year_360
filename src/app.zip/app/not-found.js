import React from 'react'
import { Layouts } from './Component'

const NotFound = () => {
  return (
    <Layouts>
        <div>not-found</div>
    </Layouts>
  )
}

export default NotFound