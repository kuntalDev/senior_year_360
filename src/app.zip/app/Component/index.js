import Layouts from './Layout';
import SectionLoader from './Widgets/SectionLoader'
import Loader from './Widgets/Loader'

export {
    Layouts, SectionLoader, Loader
}